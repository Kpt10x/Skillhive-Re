import { Component } from '@angular/core';

@Component({
  selector: 'app-viewassessment',
  imports: [],
  templateUrl: './viewassessment.component.html',
  styleUrl: './viewassessment.component.css'
})
export class ViewassessmentComponent {

}
