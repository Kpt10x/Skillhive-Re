export interface Instructor {
  id: number;
  name: string;
  email: string;
  phone: string;
  areaOfExpertise: string;
  experience: number;
  start_date: string;
  end_date: string;
}
