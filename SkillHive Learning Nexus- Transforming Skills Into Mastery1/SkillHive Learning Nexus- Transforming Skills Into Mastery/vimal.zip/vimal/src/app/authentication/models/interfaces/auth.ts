export interface  profiles{
    id?: string;
    fullName: string;
    email: string;
    password: string;
    role: string;
}
